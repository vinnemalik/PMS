package com.cts.policyManagmentSystem.service;

import com.cts.policyManagmentSystem.bean.User;

public interface RegistrationService {
	public String addUser(User user);
}
