package com.cts.policyManagmentSystem.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.policyManagmentSystem.bean.User;
import com.cts.policyManagmentSystem.service.RegistrationService;

@Controller
public class RegistartionController {

	@Autowired
	RegistrationService registrationService;
	
	@RequestMapping("successful.html")
	public String getSuccessfulPage(){
		return "successful";
	}
	
	@RequestMapping("registration12.html")
	public ModelAndView getRegistrationPage(@ModelAttribute User user,HttpSession httpSession){
		ModelAndView modelAndView= new ModelAndView();
		modelAndView.setViewName("registration");
		return modelAndView;
	}
	
	@PostMapping("registration.html")
	public ModelAndView registerUser(@ModelAttribute User user,HttpSession httpSession)
	{
		ModelAndView modelAndView = new ModelAndView();
		if("true".equals(registrationService.addUser(user)))
		{
			//System.out.println(user);
			
			modelAndView.setViewName("successful");
			return modelAndView;
		}
		else
		{
			System.out.println("FAILED");
			return null;
		}
	
		
	}
}
