package com.cts.policyManagmentSystem.service;

import java.util.List;

import com.cts.policyManagmentSystem.bean.Policy;

public interface PolicyService {
	public String addPolicy(Policy policy);
	public List<Policy> getAllPolicy();
	public String updatePolicy(Policy policy);
	public Policy getPolicyById(String policyId);
}
